declare function initNotify():void;
export = initNotify;
